"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const app_controller_1 = require("./controller/app/app.controller");
const test_controller_1 = require("./controller/test/test.controller");
function Routing(router, multipart) {
    const testController = new test_controller_1.TestController();
    //it will call function in controller by the link
    router.get('/test/test1', testController.TestJSON);
    const appController = new app_controller_1.AppController();
    router.get('/app/version', appController.getAppVersion);
}
exports.Routing = Routing;
//# sourceMappingURL=route.js.map