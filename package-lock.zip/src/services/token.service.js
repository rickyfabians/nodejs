"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var vEnv = require('../config/mode.json')['mode'];
class Token {
}
exports.Token = Token;
//# sourceMappingURL=token.service.js.map