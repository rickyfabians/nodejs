import Assets from '../models/assets.models';

export class dataAccessAssets{

    getAllAssets(){
    }



}