"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class dataAccessAssets {
    getAllAssets() {
    }
}
exports.dataAccessAssets = dataAccessAssets;
//# sourceMappingURL=Assets.dataAccess.js.map