"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class dataAccessAssets {
    getAllAssets() {
    }
}
exports.dataAccessAssets = dataAccessAssets;
//# sourceMappingURL=assets.dataAccess.js.map