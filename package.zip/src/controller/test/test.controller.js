"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const logging_service_1 = require("./../../services/logging.service");
const error_handling_service_1 = require("../../services/error-handling.service");
const successresponse_models_1 = require("../../models/successresponse.models");
// var User = require('./../models/user');
const vEnv = require('../../config/mode.json')['mode'];
const vConfig = require('../../config/config.json')[vEnv];
var mongoose = require('mongoose');
class TestController {
    constructor() {
        logging_service_1.Logging("Instantiate App Controller..");
    }
    TestJSON(pRequest, pResponse) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var result = [{ "nama": "ricky" }, { "nama": "dodi" }, { "nama": "andi" }, { "nama": "gama" }];
                pResponse.status(200).json(successresponse_models_1.SuccessResponseModel.getSuccessResp({ 'result': result }));
            }
            catch (err) {
                logging_service_1.Logging(err);
                if (err.code) {
                    error_handling_service_1.ErrorHandlingService.throwHTTPErrorResponse(pResponse, 500, err.code, err.desc);
                }
                else {
                    error_handling_service_1.ErrorHandlingService.throwHTTPErrorResponse(pResponse, 500, 54000, err);
                }
            }
        });
    }
    getAllAssets(req, res, next) {
        return __awaiter(this, void 0, void 0, function* () {
            // assets.getAllAssets().then(
            //     resolve => {
            //         res.status(200).json(resolve);
            //     },
            //     reject =>{
            //         console.log(reject);
            //         res.status(400).json(reject);
            //     }
            // )
        });
    }
}
exports.TestController = TestController;
//# sourceMappingURL=test.controller.js.map